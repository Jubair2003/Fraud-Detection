package com.datamantra.fraudalertdashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
@SpringBootApplication
public class FraudAlertDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(FraudAlertDashboardApplication.class, args);
	}
}

*/